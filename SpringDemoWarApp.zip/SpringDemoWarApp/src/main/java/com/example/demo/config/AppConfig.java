package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

//@Configuration
public class AppConfig {

//	@Bean
//	public InternalResourceViewResolver viewResolver() {
//		InternalResourceViewResolver itr = new InternalResourceViewResolver();
//		itr.setSuffix(".jsp");
//		return itr; 
//	}
}
