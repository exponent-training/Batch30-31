package com.example.Batch31SpringBootJPA;

import org.springframework.data.repository.CrudRepository;

public interface StudentRepositry extends CrudRepository<Student, Integer>{
	
	

}
