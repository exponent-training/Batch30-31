package com.example.Batch31SpringBootJPA;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

@SpringBootApplication
public class Batch31SpringBootJpaApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(Batch31SpringBootJpaApplication.class, args);

		StudentRepositry sr = context.getBean(StudentRepositry.class);
//		System.out.println(sr.getClass());

		Student s = new Student();
		s.setSid(2);
		s.setSname("was");
		s.setMarks(75.78);

		Student s1 = new Student();
//		s1.setSid();
		s1.setSname("erty");
		s1.setMarks(36.21);

//		sr.save(s);
//		sr.saveAll(Arrays.asList(s,s1));
//		System.out.println(sr.findAll());
//		System.out.println(sr.findById(2));
//		System.out.println(sr.findAllById(Arrays.asList(2,3)));
//		System.out.println(sr.existsById(3));
//		System.out.println(sr.count());
//		sr.delete();//entity
//		sr.deleteAll();//all
//		sr.deleteAllById(list of ids );
//		sr.deleteById(3);
//		sr.deleteAll(entities);
		
//		sr.save(s);//save as update >> UPSERT
		
//		PagingAndSortingRepository<T, ID>
//		JpaRepository<T, ID>
		
	}

}
