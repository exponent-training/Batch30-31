package com.example.Batch31SpringBootJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch31SpringBootJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
