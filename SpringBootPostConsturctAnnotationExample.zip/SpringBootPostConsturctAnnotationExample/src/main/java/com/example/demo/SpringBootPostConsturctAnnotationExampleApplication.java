package com.example.demo;

import java.io.File;
import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.ResourceUtils;

@SpringBootApplication
public class SpringBootPostConsturctAnnotationExampleApplication {

	@Autowired
	ResourceLoader resourceLoader;
	
	@Value("classpath:AjasShaikh.txt")
	Resource resource;
	
	@Value("${fileDir}")
	private String pathNew;
	
	@PostConstruct
	public void gettingFile() throws IOException {
		System.out.println("Checking Method Call.");
		Resource resource = resourceLoader.getResource("classpath:AjasShaikh.txt");
		File file = resource.getFile();
		System.out.println(file.getName());
	}
	
	@PostConstruct
	public void gettingFileData() throws IOException {
		System.out.println("GettingFileData Method Call.");
		File file = resource.getFile();
		System.out.println(file.getName());
		//ClassPathResouce
		File file1 = ResourceUtils.getFile("classpath:AjasShaikh.txt");
		System.out.println("Using ResourceUtils : " +file1.getName());
		System.out.println("========================================="+pathNew);
		File file2 = ResourceUtils.getFile(pathNew);
		System.out.println("Using Other File Path location : " +file2.getName());
		
	}
	public static void main(String[] args) {
		SpringApplication.run(SpringBootPostConsturctAnnotationExampleApplication.class, args);
	}

}
