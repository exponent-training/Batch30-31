package com.springMVC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springMVC.model.Student;
import com.springMVC.service.StudentService;

@Controller
public class MyController {

	@Autowired
	private StudentService service;

	@RequestMapping(value = "/reg")
	public String register(@ModelAttribute Student student, Model model) {// @RequeatParam //@ModelArrtribute

		System.out.println("Student Data Controller : " + student);

		service.registerStudent(student);

		return "success";// view //map k y

	}
	
	@RequestMapping(value="/log")
	public String login(@RequestParam("user") String username,@RequestParam String pass,Model model) {
		
		if(username.equals("admin") && pass.equals("admin@123")) {
			
			List<Student> slist=service.getStudents();
			
			model.addAttribute("slist",slist);
			
			return "details";
		}else {
			return "warning";
		}
		
	}
	
	@RequestMapping(value="/del")
	public String delete(@RequestParam int sid) {
		
		service.delStudent(sid);
		
		
		return "login";
	}
	
	
	
	

}
