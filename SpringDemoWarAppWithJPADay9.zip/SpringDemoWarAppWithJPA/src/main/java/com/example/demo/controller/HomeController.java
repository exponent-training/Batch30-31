package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Student;
import com.example.demo.service.HomeService;

@Controller
public class HomeController {
	
	@Autowired
	private HomeService homeService;
	
	@RequestMapping(value = "/")
	public String getIndexpage() {
		return "index";
	}
	
	@RequestMapping(value = "/reg",method = RequestMethod.POST)
	public String getRegisteredData(@ModelAttribute Student student) {
		System.out.println("In Controller : " + student);
		homeService.saveData(student);
		return "index";
	}

	@RequestMapping(value = "/log",method = RequestMethod.POST)
	public String getLoginData(@RequestParam String uname,@RequestParam String pass,Model model) {
		System.out.println("Login Check : " + uname + "  " + pass);
		Student student = homeService.getLoginCheck(uname, pass);
		if(student != null) {
			model.addAttribute("stu", student);
			return "success";
		} else {
		    String str = "Invalid Credentials.";
			model.addAttribute("s", str);
			return "login";
		}
	}
	
	@RequestMapping(value = "/editnew")
	public String getEditedData(@RequestParam int id,Model model) {
		System.out.println("Edited Data : " + id);
		Student student = homeService.getStudentDataUsingId(id);
		model.addAttribute("stud", student);
		return "edit";
	}
	
	@RequestMapping(value = "/up",method = RequestMethod.POST)
	public String getUpdatedData(@ModelAttribute Student student) {
		System.out.println("Get Updated Data : " + student);
		homeService.updateStudentData(student);
		return "index";
	}
}
