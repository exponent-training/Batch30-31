package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repo.HomeRepository;

@Service
public class HomeServiceImpl implements HomeService{

	@Autowired
	private HomeRepository homeRepository;
	
	@Override
	public void saveData(Student student) {
		// TODO Auto-generated method stub
		System.out.println("In Service layer: " + student);
		homeRepository.save(student);
	}

	@Override
	public Student getLoginCheck(String uname, String pass) {
		// TODO Auto-generated method stub
		Student student = homeRepository.findByUnameAndPass(uname, pass);
		return student;
	}

	@Override
	public Student getStudentDataUsingId(int id) {
		// TODO Auto-generated method stub
		Student student = homeRepository.findById(id).get();
		return student;
	}

	@Override
	public void updateStudentData(Student student) {
		// TODO Auto-generated method stub
		System.out.println("Checking Updated Data : " + student);
		homeRepository.save(student);
	}

}
