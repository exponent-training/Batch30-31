package com.example.demo.service;

import com.example.demo.entity.Student;

public interface HomeService {

	void saveData(Student student);
	
	Student getLoginCheck(String uname,String pass);
	
	Student getStudentDataUsingId(int id);
	
	void updateStudentData(Student student);
}
