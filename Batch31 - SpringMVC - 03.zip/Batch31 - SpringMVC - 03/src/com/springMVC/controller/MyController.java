package com.springMVC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springMVC.model.Student;

@Controller
public class MyController {
	
	@RequestMapping(value="/reg")
	public String register(@ModelAttribute Student student,Model model) {//@RequeatParam  //@ModelArrtribute
		
		System.out.println("Student Data : "+student);
		
		if(student.getSid()>10) {
			model.addAttribute("msg","Succefully register in database");
			
			model.addAttribute("stu", student);
			
			return "success";//view
		}else {
			return "warning";
		}
		
	
	}
	
	
	
	

}
