package com.springMVC.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springMVC.dao.AppDao;
import com.springMVC.model.User;

@Service
public class AppServiceImpl implements AppService {

	@Autowired
	private AppDao dao;
	@Override
	public void registerService(User user) {
		
		dao.registerDao(user);
	}
	@Override
	public User loginService(String id, String accPin) {
		
		return dao.loginDao(id, accPin);
	}
	@Override
	public User depositeService(String id, String pin, double depositeMoney) {
		
		return dao.depositeDao(id, pin, depositeMoney);
		
	}
	@Override
	public User withdrawService(String id, String pin, double withdrawMoney) {
		// TODO Auto-generated method stub
		return dao.withdrawMoneyDao(id, pin, withdrawMoney);
	}

}
