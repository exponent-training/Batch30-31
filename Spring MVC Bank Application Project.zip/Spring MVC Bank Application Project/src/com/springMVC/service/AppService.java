package com.springMVC.service;

import com.springMVC.model.User;

public interface AppService {

	void registerService(User user);

	User loginService(String id, String accPin);

	User depositeService(String id, String pin, double depositeMoney);

	User withdrawService(String id, String pin, double withdrawMoney);

}
