package com.springMVC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springMVC.model.User;
import com.springMVC.service.AppService;

@Controller
public class MyController {

	@Autowired
	private AppService service;

	@RequestMapping(value = "/register")
	public String register(@ModelAttribute User user) {

		service.registerService(user);

		return "registerSuccess";
	}

	@RequestMapping(value = "/login")
	public String login(@RequestParam String id, @RequestParam String accPin, Model model) {

		User user = service.loginService(id, accPin);

		if (user != null) {
			model.addAttribute("user", user);
			return "successLogin";
		} else {
			return "invalid";
		}
	}

	@RequestMapping(value = "/deposite")
	public String deposite(@RequestParam String id, @RequestParam String pin, @RequestParam double depositeMoney, Model model) {

		User user = service.depositeService(id, pin, depositeMoney);
		model.addAttribute("user",user);

		return "success";
	}
	
	@RequestMapping(value = "/withdraw")
	public String withdrawService(@RequestParam String id, @RequestParam String pin, @RequestParam double withdrawMoney , Model model) {
		
		User user = service.withdrawService(id, pin,withdrawMoney );
		model.addAttribute("user", user);
		return "success";
	}
}
