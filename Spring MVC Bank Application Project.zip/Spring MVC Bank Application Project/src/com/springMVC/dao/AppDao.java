package com.springMVC.dao;

import com.springMVC.model.User;

public interface AppDao {

	void registerDao(User user);

	User loginDao(String id, String accPin);

	User depositeDao(String id, String pin, double depositeMoney);

	User withdrawMoneyDao(String id, String pin, double withdrawMoney);

}
