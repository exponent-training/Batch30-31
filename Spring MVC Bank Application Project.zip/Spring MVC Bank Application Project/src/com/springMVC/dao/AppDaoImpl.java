package com.springMVC.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springMVC.model.User;

@Repository
public class AppDaoImpl implements AppDao{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public void registerDao(User user) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		session.save(user);
		session.beginTransaction().commit();
		
	}

	@Override
	public User loginDao(String id, String accPin) {
		
		 Session session =sf.openSession();
		 User user = session.get(User.class, id);
		 return user;
	
	}

	@Override
	public User depositeDao(String id, String pin, double depositeMoney) {
		Session session = sf.openSession();
		
		User user = session.get(User.class, id);
		if(user != null) {
			user.setDeposite(user.getDeposite() + depositeMoney);
			session.update(user);
			session.save(user);
			session.beginTransaction().commit();
			
			System.out.println("Successfully deposite");
			
		}
		return user;
	}

	@Override
	public User withdrawMoneyDao(String id, String pin, double withdrawMoney) {
		Session session = sf.openSession();
		
		User user = session.get(User.class, id);
		
		if(user != null) {
			user.setDeposite(user.getDeposite() - withdrawMoney);
			session.update(user);
			session.save(user);
			session.beginTransaction().commit();
		}
		return user;
	}

}
