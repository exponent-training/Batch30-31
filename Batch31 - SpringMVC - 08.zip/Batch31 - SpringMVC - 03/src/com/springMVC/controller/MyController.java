package com.springMVC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.springMVC.model.Student;
import com.springMVC.service.StudentService;

@Controller
public class MyController {
	
	

	@Autowired
	private StudentService service;
	
	@RequestMapping(value = "/reg",method=RequestMethod.POST)//GET POST
	public String register(@ModelAttribute Student student,@RequestParam("fileUp") MultipartFile fileUp, Model model) {// @RequeatParam //@ModelArrtribute

		System.out.println("Student Data Controller : " + student);

		try {
			byte[] file=fileUp.getBytes();
			student.setFileUpload(file);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		service.registerStudent(student);

		return "success";// view //map k y

	}
	
	@RequestMapping(value="/log")
	public String login(@RequestParam("user") String username,@RequestParam String pass,Model model) {
		
		if(username.equals("admin") && pass.equals("admin@123")) {
			
			List<Student> slist=service.getStudents();
			
			model.addAttribute("slist",slist);
			
			return "details";
		}else {
			return "warning";
		}
		
	}
	
	@RequestMapping(value="/del")
	public String delete(@RequestParam int sid) {
		
		service.delStudent(sid);
		
		
		return "login";
	}
	
	
	@RequestMapping(value="/edit")
	public String editData(@RequestParam int sid,Model model) {
		
		Student s=service.getSingleStudent(sid);
		
		model.addAttribute("stu",s);
		
		return "edit";
		
	}
	
	@RequestMapping(value="/up")
	public String update(@ModelAttribute Student s) {
		
		System.out.println("UPdated data : "+s);
		
		service.updateData(s);
		
		return "login";
	}
	

}
