package com.springMVC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springMVC.model.Student;
import com.springMVC.service.StudentService;

@Controller
public class MyController {
	
	@Autowired
	private StudentService service;
	
	@RequestMapping(value="/reg")
	public String register(@ModelAttribute Student student,Model model) {//@RequeatParam  //@ModelArrtribute
		
		System.out.println("Student Data Controller : "+student);
		
		service.registerStudent(student);
		
		if(student.getSid()>10) {
			model.addAttribute("msg","Succefully register in database");
			
			model.addAttribute("stu", student);
			
			return "success";//view //map k y
		}else {
			return "warning";
		}
		
	
	}
	
	
	
	

}
