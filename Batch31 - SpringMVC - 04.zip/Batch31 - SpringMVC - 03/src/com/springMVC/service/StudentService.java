package com.springMVC.service;

import com.springMVC.model.Student;

public interface StudentService {
	
	void registerStudent(Student s);
	
	

}
