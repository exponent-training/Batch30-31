package com.springMVC.dao;

import com.springMVC.model.Student;

public interface StudentDao {
	
	void addStudent(Student s);

}
