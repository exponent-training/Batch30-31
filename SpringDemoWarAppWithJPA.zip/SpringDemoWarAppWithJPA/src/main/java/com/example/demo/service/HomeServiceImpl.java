package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repo.HomeRepository;

@Service
public class HomeServiceImpl implements HomeService{

	@Autowired
	private HomeRepository homeRepository;
	
	@Override
	public void saveData(Student student) {
		// TODO Auto-generated method stub
		System.out.println("In Service layer: " + student);
		homeRepository.save(student);
	}

}
