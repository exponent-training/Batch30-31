package com;

public class MySQL implements Connection{
	
	public void on() {
		System.out.println("MySQL is On");
	}
	
	public MySQL() {
		System.out.println("MySQL constructor");
	}
	

}
