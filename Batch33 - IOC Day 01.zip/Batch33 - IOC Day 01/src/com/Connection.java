package com;

public interface Connection {
	
	void on();

}
