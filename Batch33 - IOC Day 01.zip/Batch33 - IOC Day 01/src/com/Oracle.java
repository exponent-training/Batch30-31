package com;

public class Oracle implements Connection{

	public void on() {
		System.out.println("Orcale is On");
	}
	
	public Oracle() {
		System.out.println("Oracle constructor");
	}
	
}
