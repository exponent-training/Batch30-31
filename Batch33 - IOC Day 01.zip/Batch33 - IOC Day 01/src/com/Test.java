package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	
	public static void main(String[] args) {
		
//		Connection c= new MySQL();
//		c.on();
//		
//		Connection c1= new Oracle();
//		c1.on();
		
//		MySQL m=new MySQL();
		
		
		//Containers
//		-resposible xml read
//		-bean create
//		-bean life cycle
//		-bean distory
		
//		core                 
//		BeanFactory(I)  
//		XmlBeanFactory(C)
//		Need to provide resource because can't read xml directly
//		Deprecated
//		Lazy loading
		
		
//		J2EE
//		ApplicationContext(I)
//		ClassPathXmlApplicationContext(C)
//		No need provide resource can read xml directly
//		New concept
//		internally it calls BeanFactory
//		Egar loading
		
		
		
		Resource resource=new ClassPathResource("NewFile.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resource);
		
		Connection c1 =(Connection)beanFactory.getBean("m");//object
//		c1.on();
		
		
	}

}
