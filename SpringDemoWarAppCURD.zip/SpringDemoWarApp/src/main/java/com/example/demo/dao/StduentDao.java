package com.example.demo.dao;

import com.example.demo.entity.Student;

public interface StduentDao {

	void saveStudentData(Student student);
}
