package com.example.demo.config;

import java.util.Properties;

import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.example.demo.entity.Student;

@Configuration
public class AppConfig {

//	@Bean
//	public InternalResourceViewResolver viewResolver() {
//		InternalResourceViewResolver itr = new InternalResourceViewResolver();
//		itr.setSuffix(".jsp");
//		return itr; 
//	}
	
	@Bean
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/springbootbatch31demo");
		ds.setUsername("root");
		ds.setPassword("root");
		
		return ds;
	}
	
	@Bean
	public LocalSessionFactoryBean getSessionFactoryBean() {
		LocalSessionFactoryBean sf = new LocalSessionFactoryBean();
		sf.setDataSource(dataSource());
		
		Properties properties = new Properties();
		properties.setProperty(Environment.HBM2DDL_AUTO, "update");
		properties.setProperty(Environment.SHOW_SQL, "true");
		properties.setProperty(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
		
		sf.setHibernateProperties(properties);
		sf.setAnnotatedClasses(Student.class);
		
		return sf;
	}
}
