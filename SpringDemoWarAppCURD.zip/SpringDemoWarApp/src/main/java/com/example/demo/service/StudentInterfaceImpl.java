package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.StduentDao;
import com.example.demo.entity.Student;

@Service
public class StudentInterfaceImpl implements ServiceInterface{

	@Autowired
	private StduentDao sd;
	
	@Override
	public void SaveStudentData(Student student) {
		// TODO Auto-generated method stub
		System.out.println("in Service Layer :  " + student);
		sd.saveStudentData(student);
	}

}
