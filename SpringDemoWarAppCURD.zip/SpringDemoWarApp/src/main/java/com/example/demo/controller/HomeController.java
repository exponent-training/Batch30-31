package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Student;
import com.example.demo.service.ServiceInterface;

@Controller
public class HomeController {

	@Autowired
	private ServiceInterface st;
	
	@RequestMapping(value = "/")
	public String getIndex() {
		return "index";
	}
	
	@RequestMapping(value = "/reg")
	public String getRegisterPage() {
		System.out.println("Calling Register Page.");
		return "register";
	}
	
	@RequestMapping(value = "/register")
	public String  getregisterPageData(@ModelAttribute Student student) {
		System.out.println("Check Student Register Data :" +student);
		st.SaveStudentData(student);
		return "index";
	}
	
}
