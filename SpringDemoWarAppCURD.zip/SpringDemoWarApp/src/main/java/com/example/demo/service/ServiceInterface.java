package com.example.demo.service;

import com.example.demo.entity.Student;

public interface ServiceInterface {

	void SaveStudentData(Student student);
}
