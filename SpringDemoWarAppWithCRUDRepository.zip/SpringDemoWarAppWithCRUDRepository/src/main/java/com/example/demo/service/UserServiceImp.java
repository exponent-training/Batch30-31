package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repo.UserRepository;

@Service
public class UserServiceImp implements UserServicei{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("In Service Layer : " + userRepository);
		userRepository.save(user);
	}

}
