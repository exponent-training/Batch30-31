package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Student;

public interface ExampleService {

	Student getStudentData();
	
	List<Student> getAll();
}
