package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.ExampleService;

@RestController
public class ExampleController {
	
	@Autowired
	private ExampleService exampleService;

	@GetMapping(value = "/")
	public String getData() {
		return "Hello Calling GetData.";
	}
	
	@GetMapping(value = "/getStu")
	public Student getStudent() {
		Student student = exampleService.getStudentData();
		return student;
	}
	
	@GetMapping(value = "/getallStu")
	public List<Student> getAllStudent() {
		List<Student> students = exampleService.getAll();
		return students;
	}
	 
}
