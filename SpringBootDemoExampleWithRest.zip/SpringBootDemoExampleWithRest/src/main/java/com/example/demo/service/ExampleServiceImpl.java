package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Student;

@Service
public class ExampleServiceImpl implements ExampleService{

	@Override
	public Student getStudentData() {
		// TODO Auto-generated method stub
		Student student = new Student();
		student.setId(123);student.setName("Abcd");
		student.setAddress("Pune");
		return student;
	}

	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		Student student = new Student();
		student.setId(123);student.setName("Abcd");
		student.setAddress("Pune");
		
		Student student1 = new Student();
		student1.setId(231);student1.setName("DCBA");
		student1.setAddress("Pune");
		
		List<Student> list = new ArrayList<>();
		list.add(student);list.add(student1);
		return list;
	}

}
