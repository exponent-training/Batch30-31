package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Configuration
//@Component
public class AppConfig {
	
	@Bean
	public Car carBean() {
		
		Car c= new Car();
		c.setCid(11);
		c.setCname("Abc");
		
		return c;
	}
	
	@Bean(name ="car")
	public Car carBean1() {
		
		Car c= new Car();
		c.setCid(12);
		c.setCname("pqr");
		
		return c;
	}
	
	@Bean(name= "t")
	@Scope(value="prototype")
	public Tata tataBean() {
		
		Tata t= new Tata();
		t.setId(45);
		t.setName("Harrier");
//		t.setCar(carBean());
		
		return t;
		
	}
	
	

}
