package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	
	public static void main(String[] args) {
		
//		-injection
//		runtime obj creation time we are passing values
		
//		-Property base injection / setter-getter base
//		-<property/>
//		-need to provide setter-getter in pojo class
//		-not compulsory to pass all values
//		-sequence of setting doesn't matter
		
//		-Constructor Base Injection
//		-<constructor-arg/>
//		-need to provide paramertise constructor
//		-it's compulsory to pass all values
//		-sequence of passing arg matter (index)
		
		
		ApplicationContext apc= new ClassPathXmlApplicationContext("NewFile.xml");
		
		Student s=(Student)apc.getBean("s");
		System.out.println(s);
		
		College c=apc.getBean("c",College.class);
		System.out.println(c);
		
		
	}

}
