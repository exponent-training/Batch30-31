package com.springMVC.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springMVC.model.Student;

@Controller
public class MyController {
	
//	3.0
	@RequestMapping(value ="/log")
	public String getLogin(@RequestParam("user") String username,@RequestParam String pass) {
		
		System.out.println("Username : "+username);
		System.out.println("Password : "+pass);
		System.out.println("Hello i am here");
		
		return "success";
	}
	
	
	@RequestMapping(value="/reg")
	public String register(@ModelAttribute Student s) {
		
		System.out.println(s);
		
		
		return "success";
	}
	
//	@RequestMapping(value ="/log")
//	public String getLogin2(@RequestParam("user") String username,@RequestParam String pass) {
//		
//		System.out.println("Username : "+username);
//		System.out.println("Password : "+pass);
//		System.out.println("Hello i am here");
//		
//		return "success";
//	}
	

}
